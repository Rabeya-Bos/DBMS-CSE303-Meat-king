-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2025 at 12:11 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mking`
--

-- --------------------------------------------------------

--
-- Table structure for table `admininfo`
--

CREATE TABLE `admininfo` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `status` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admin_t`
--

CREATE TABLE `admin_t` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `role` varchar(50) NOT NULL DEFAULT 'admin',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cart_items`
--

CREATE TABLE `cart_items` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `product_name` varchar(255) NOT NULL,
  `offer_price` decimal(10,2) NOT NULL,
  `status` enum('in_cart','ordered','cancelled') DEFAULT 'in_cart',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `coldstorage`
--

CREATE TABLE `coldstorage` (
  `coldstorageid` int(11) NOT NULL,
  `capacity` int(11) NOT NULL,
  `retailerstorage_id` int(11) NOT NULL,
  `wholesalerstorage_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `take` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `coldstorage`
--

INSERT INTO `coldstorage` (`coldstorageid`, `capacity`, `retailerstorage_id`, `wholesalerstorage_id`, `quantity`, `take`, `date`) VALUES
(1, 44, 444, 4445, 44, 444, '2222-03-03'),
(2, 44, 444, 4446, 44, 444, '2222-03-03'),
(3, 33, 444, 3333, 333, 33344, '2222-02-02'),
(4, 33, 444, 3333, 333, 33344, '2222-02-02'),
(5, 111, 122, 234, 44, 33344, '2222-04-04'),
(6, 111, 122, 234, 44, 33344, '2222-04-04');

-- --------------------------------------------------------

--
-- Table structure for table `consumer_orders_t`
--

CREATE TABLE `consumer_orders_t` (
  `order_id` int(11) NOT NULL,
  `consumer_id` int(11) NOT NULL,
  `retailer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `order_status` enum('Pending','Completed','Cancelled') DEFAULT 'Pending',
  `delivery_address` varchar(255) NOT NULL,
  `total_price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `consumer_o_t`
--

CREATE TABLE `consumer_o_t` (
  `consumerid` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `coustomer`
--

CREATE TABLE `coustomer` (
  `consumerid` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `directory`
--

CREATE TABLE `directory` (
  `id` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `designation` enum('Consumer','Farmer','Wholesaler','Retailer') DEFAULT NULL,
  `seller_or_buyer` enum('Seller','Buyer') DEFAULT NULL,
  `address` text DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `product` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `livestocks_or_product` enum('Livestock','Product') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `farmer`
--

CREATE TABLE `farmer` (
  `farmer_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `date_joined` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `historical_data`
--

CREATE TABLE `historical_data` (
  `id` int(11) NOT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `current_price` decimal(10,2) DEFAULT NULL,
  `offer_price` decimal(10,2) DEFAULT NULL,
  `order_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `historical_data`
--

INSERT INTO `historical_data` (`id`, `product_name`, `current_price`, `offer_price`, `order_date`) VALUES
(1, 'Beef Steak', 20.00, 15.00, '2025-04-26 17:23:41'),
(2, 'Chicken Breast', 10.00, 8.50, '2025-04-26 17:23:47'),
(3, 'meat lofe', 2500.00, 1800.00, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `item_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `item_type` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `date_added` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `livestock`
--

CREATE TABLE `livestock` (
  `livestock_batch_id` int(11) NOT NULL,
  `season` varchar(100) DEFAULT NULL,
  `marketage` int(11) DEFAULT NULL,
  `feed_type` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `livestock`
--

INSERT INTO `livestock` (`livestock_batch_id`, `season`, `marketage`, `feed_type`) VALUES
(2, 'spring', 44, 'corn'),
(3, 'winter', 13, 'filex');

-- --------------------------------------------------------

--
-- Table structure for table `meat_product_t`
--

CREATE TABLE `meat_product_t` (
  `id` int(11) NOT NULL,
  `meat_type` varchar(255) NOT NULL,
  `cut` varchar(255) NOT NULL,
  `origin` varchar(255) NOT NULL,
  `seasonality` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `product_id` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `meat_product_t`
--

INSERT INTO `meat_product_t` (`id`, `meat_type`, `cut`, `origin`, `seasonality`, `price`, `created_at`, `product_id`) VALUES
(4, 'beef', 'big checks', 'local', 'year-round', 34555.00, '2025-04-24 00:09:42', '001'),
(5, 'beef', 'big checks', 'local', 'year-round', 34555.00, '2025-04-24 00:12:42', '007'),
(6, 'beef', 'big checks raw', 'local', 'year-round', 5000.00, '2025-04-24 00:13:18', '022'),
(7, 'beef', 'raw', 'local', 'year-round', 5001.00, '2025-04-24 00:13:37', '003'),
(8, 'chicken', 'raw', 'local', 'year-round', 5002.00, '2025-05-04 05:45:44', '8');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `product_name` varchar(255) NOT NULL,
  `offer_price` decimal(10,2) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `product_name`, `offer_price`, `order_date`) VALUES
(1, 1, 'Beef Steak', 15.00, '2025-04-26 11:48:19'),
(2, 1, 'Beef Steak', 15.00, '2025-04-26 11:50:19');

-- --------------------------------------------------------

--
-- Table structure for table `orders_o_t`
--

CREATE TABLE `orders_o_t` (
  `order_id` int(11) NOT NULL,
  `consumerid` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `order_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders_o_t`
--

INSERT INTO `orders_o_t` (`order_id`, `consumerid`, `product_id`, `quantity`, `order_date`) VALUES
(3, 1, 3, 1, '2222-01-12'),
(4, 1, 3, 22, '2222-02-22');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `meat_type` varchar(255) NOT NULL,
  `cut` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `origin` varchar(255) NOT NULL,
  `seasonality` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `meat_type`, `cut`, `price`, `origin`, `seasonality`, `created_at`) VALUES
(4, 'beef', 'big checks raw', 1000.00, '', '', '2025-04-25 17:43:02'),
(5, 'chicken', 'big checks', 100.00, '', '', '2025-04-25 17:53:49'),
(6, 'chicken1', 'big checks', 102.00, '', '', '2025-04-25 18:03:20'),
(10, 'chicken12', 'raw', 100.00, '', '', '2025-04-26 13:27:57'),
(11, 'chicken12', 'big checks', 100.00, '', '', '2025-05-04 06:09:03');

-- --------------------------------------------------------

--
-- Table structure for table `production_record_t`
--

CREATE TABLE `production_record_t` (
  `id` int(11) NOT NULL,
  `yield_kg` float NOT NULL,
  `livestock_no` int(11) NOT NULL,
  `cost` float NOT NULL,
  `area_acre` varchar(100) DEFAULT NULL,
  `farmer_id` int(11) NOT NULL,
  `production_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `production_record_t`
--

INSERT INTO `production_record_t` (`id`, `yield_kg`, `livestock_no`, `cost`, `area_acre`, `farmer_id`, `production_date`) VALUES
(15, 25, 22, 323, 'pending', 1, '4444-04-04'),
(16, 455, 555, 35677, 'pending', 1, '2222-05-04'),
(17, 666, 6667, 6444440, 'pending', 1, '2222-05-23'),
(18, 9999, 99999, 999999, 'pending', 1, '2222-03-31'),
(30, 33, 300, 30000, 'holding', 9, '2023-02-23');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_reviews`
--

CREATE TABLE `product_reviews` (
  `id` int(11) NOT NULL,
  `product` varchar(50) DEFAULT NULL,
  `quantity` float DEFAULT NULL,
  `review` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_transactions`
--

CREATE TABLE `product_transactions` (
  `id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `product_name` varchar(100) DEFAULT NULL,
  `person_name` varchar(100) DEFAULT NULL,
  `quantity` float DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `review` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `type` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_transactions`
--

INSERT INTO `product_transactions` (`id`, `product_id`, `product_name`, `person_name`, `quantity`, `price`, `review`, `created_at`, `type`) VALUES
(36, 33, 'beef', 'wholesaler2', 11, 1000.00, 'srimongol', '2025-05-04 03:45:40', 'Buyer'),
(37, 33, 'beef', 'wholesaler13', 11, 1000.00, 'uttora', '2025-05-04 03:46:50', 'Seller'),
(38, 33, 'beef', 'retailer', 11, 1000.00, 'uttora', '2025-05-04 03:50:03', 'Seller'),
(39, 33, 'beef', 'wholesaler1', 11, 1000.00, 'uttora', '2025-05-04 03:51:37', 'Seller'),
(40, 33, 'chicken', 'retailer', 5, 6000.00, 'Rampura', '2025-05-04 04:00:56', 'Buyer'),
(41, 33, 'chicken', 'rabeya', 33, 1000.00, 'ramna', '2025-05-04 06:06:53', NULL),
(42, 33, 'chicken', 'retailer', 50, 6000.00, 'Rampura', '2025-05-04 06:12:16', 'Buyer');

-- --------------------------------------------------------

--
-- Table structure for table `recommendation`
--

CREATE TABLE `recommendation` (
  `id` int(11) NOT NULL,
  `farmer_id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `batch_no` varchar(255) DEFAULT NULL,
  `recommendation` text DEFAULT NULL,
  `date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `recommendations`
--

CREATE TABLE `recommendations` (
  `id` int(11) NOT NULL,
  `farmer_id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `batch_no` varchar(255) DEFAULT NULL,
  `recommendation` text DEFAULT NULL,
  `date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `recommendations`
--

INSERT INTO `recommendations` (`id`, `farmer_id`, `item_id`, `batch_no`, `recommendation`, `date`) VALUES
(1, 22, 22, '2222', '2ww', '2222-02-02 00:00:00'),
(2, 66, 6665, '55', 'vv', '2222-05-05 00:00:00'),
(3, 6, 66, '666', 'refill stock', '2222-06-06 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `retailers`
--

CREATE TABLE `retailers` (
  `retailer_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `contact_info` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `retailer_purchase_record_t`
--

CREATE TABLE `retailer_purchase_record_t` (
  `purchase_id` int(11) NOT NULL,
  `retailer_id` int(11) NOT NULL,
  `wholesaler_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `purchase_date` date NOT NULL,
  `price_per_unit` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `retailer_storage_inventory_t`
--

CREATE TABLE `retailer_storage_inventory_t` (
  `id` int(11) NOT NULL,
  `retailer_id` varchar(50) DEFAULT NULL,
  `storage_id` varchar(50) DEFAULT NULL,
  `temperature` decimal(5,2) DEFAULT NULL,
  `product_quantity_kg` decimal(10,2) DEFAULT NULL,
  `meat_type` varchar(50) DEFAULT NULL,
  `wholesaler_id` varchar(50) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `retailer_storage_inventory_t`
--

INSERT INTO `retailer_storage_inventory_t` (`id`, `retailer_id`, `storage_id`, `temperature`, `product_quantity_kg`, `meat_type`, `wholesaler_id`, `status`, `date`) VALUES
(1, '11', '10', 1.00, 11.00, 'beef', '26', 'pending', '2220-11-12'),
(3, '11', '10', 1.00, 11.00, 'beef', '23', 'pending', '3333-03-31');

-- --------------------------------------------------------

--
-- Table structure for table `retailer_t`
--

CREATE TABLE `retailer_t` (
  `retailer_id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `area` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `zipcode` varchar(10) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `selling_buying_directory`
--

CREATE TABLE `selling_buying_directory` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `product_type` varchar(100) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `singing`
--

CREATE TABLE `singing` (
  `id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `designation` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `singing`
--

INSERT INTO `singing` (`id`, `username`, `email`, `password`, `designation`) VALUES
(1, 'rab', 'rabrb01@gmail.com', '$2y$10$f9CLUdJRwYNdIIS9NFr/gurYaX9Tlt2JtM6vZKAeOLrixJ.d3SxkO', 'retailer'),
(7, 'fatima', 'fouziatujin.7@gmail.com', '$2y$10$IgAyu6JXqqfFoIUn2Mr6CeGtde.NEeCTJnneo33ILniC/cGJE9o56', 'wholesaler'),
(8, 'rab', '2230150@iub.edu.bd', '$2y$10$cxlyr.et7M8Yxumud1zDMeSjYnLyiw7REiQgPY3hmVK9SrAF0ZZkq', 'livestock farmer'),
(9, 'afsana', 'adimn01@gmail.com', '$2y$10$MhlpQbyc7HXNZryCxI6ENuOMKinSKNl58/XhQ93ViT60MrHfGP9pS', 'admin'),
(10, 'fatima', '22333@gmail.com', '$2y$10$i.R7mU8OlH5U7Lh17Lb4Dehg9LwVNqXtm.oWAFAs/d7hC6lon1aIy', 'admin'),
(12, 'kazi dibyo', 'dibyo@gmail.com', '$2y$10$Lz8h5w.1oRClmT1CMe0wN.vT2bu1anbqHHuOtOZJKvUiM.I8OVd1S', 'retailer'),
(13, 'afsana', 'afsana@gmail.com', '$2y$10$.MGTRIRp/Nj73TD1irvIB.Rjlia2XgYNmOxRaZGj17/ckehJqnh3y', 'wholesaler'),
(16, 'dibyo', 'dibyo1@gmail.com', '$2y$10$xiHwhi3oh3TQ.xeBxm05HO6Mf1Avuy0clN9blblPCDpCMnXTU5Gsu', 'consumer');

-- --------------------------------------------------------

--
-- Table structure for table `trends`
--

CREATE TABLE `trends` (
  `id` int(11) NOT NULL,
  `meat_type` varchar(100) DEFAULT NULL,
  `product_id` varchar(50) DEFAULT NULL,
  `historical_date` date DEFAULT NULL,
  `historical_price` decimal(10,2) DEFAULT NULL,
  `current_price` decimal(10,2) DEFAULT NULL,
  `trend` decimal(6,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trends`
--

INSERT INTO `trends` (`id`, `meat_type`, `product_id`, `historical_date`, `historical_price`, `current_price`, `trend`) VALUES
(2, 'clay fish', '202', '2222-03-31', 35000.00, 6000.00, -82.86),
(3, '222', '222', '2222-02-02', 222.00, 2222222.00, 9999.99),
(4, '222', '222', '2222-02-02', 222.00, 2222222.00, 9999.99),
(5, '222', '222', '2222-02-02', 222.00, 1500.00, 575.68);

-- --------------------------------------------------------

--
-- Table structure for table `wholesaler_purchase_record_t`
--

CREATE TABLE `wholesaler_purchase_record_t` (
  `purchase_id` int(11) NOT NULL,
  `wholesaler_id` int(11) NOT NULL,
  `retailer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `purchase_date` date NOT NULL,
  `price_per_unit` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wholesaler_storage_inventory_t`
--

CREATE TABLE `wholesaler_storage_inventory_t` (
  `id` int(11) NOT NULL,
  `wholesaler_id` varchar(50) DEFAULT NULL,
  `storage_id` varchar(50) DEFAULT NULL,
  `temperature` decimal(5,2) DEFAULT NULL,
  `meat_type` varchar(50) DEFAULT NULL,
  `product_quantity_kg` decimal(10,2) DEFAULT NULL,
  `retailer_id` varchar(50) DEFAULT NULL,
  `selling_quantity_kg` decimal(10,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wholesaler_storage_inventory_t`
--

INSERT INTO `wholesaler_storage_inventory_t` (`id`, `wholesaler_id`, `storage_id`, `temperature`, `meat_type`, `product_quantity_kg`, `retailer_id`, `selling_quantity_kg`, `status`, `date`) VALUES
(3, '23', '10', 2.00, 'chicken', 2.00, '60', 2.00, 'holdings', '2224-02-02'),
(4, '56', '10', -1.00, 'chicken', 4.00, '6', 1.00, 'pending', '3333-02-03');

-- --------------------------------------------------------

--
-- Table structure for table `wholesaler_t`
--

CREATE TABLE `wholesaler_t` (
  `wholesaler_id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `area` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `zipcode` varchar(10) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admininfo`
--
ALTER TABLE `admininfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_t`
--
ALTER TABLE `admin_t`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coldstorage`
--
ALTER TABLE `coldstorage`
  ADD PRIMARY KEY (`coldstorageid`);

--
-- Indexes for table `consumer_orders_t`
--
ALTER TABLE `consumer_orders_t`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `consumer_id` (`consumer_id`),
  ADD KEY `retailer_id` (`retailer_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `consumer_o_t`
--
ALTER TABLE `consumer_o_t`
  ADD PRIMARY KEY (`consumerid`);

--
-- Indexes for table `coustomer`
--
ALTER TABLE `coustomer`
  ADD PRIMARY KEY (`consumerid`);

--
-- Indexes for table `directory`
--
ALTER TABLE `directory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `farmer`
--
ALTER TABLE `farmer`
  ADD PRIMARY KEY (`farmer_id`);

--
-- Indexes for table `historical_data`
--
ALTER TABLE `historical_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `livestock`
--
ALTER TABLE `livestock`
  ADD PRIMARY KEY (`livestock_batch_id`);

--
-- Indexes for table `meat_product_t`
--
ALTER TABLE `meat_product_t`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `product_id` (`product_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders_o_t`
--
ALTER TABLE `orders_o_t`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `consumerid` (`consumerid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `production_record_t`
--
ALTER TABLE `production_record_t`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `product_reviews`
--
ALTER TABLE `product_reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_transactions`
--
ALTER TABLE `product_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `recommendation`
--
ALTER TABLE `recommendation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `recommendations`
--
ALTER TABLE `recommendations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `retailers`
--
ALTER TABLE `retailers`
  ADD PRIMARY KEY (`retailer_id`);

--
-- Indexes for table `retailer_purchase_record_t`
--
ALTER TABLE `retailer_purchase_record_t`
  ADD PRIMARY KEY (`purchase_id`),
  ADD KEY `retailer_id` (`retailer_id`),
  ADD KEY `wholesaler_id` (`wholesaler_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `retailer_storage_inventory_t`
--
ALTER TABLE `retailer_storage_inventory_t`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `retailer_t`
--
ALTER TABLE `retailer_t`
  ADD PRIMARY KEY (`retailer_id`);

--
-- Indexes for table `selling_buying_directory`
--
ALTER TABLE `selling_buying_directory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `singing`
--
ALTER TABLE `singing`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `trends`
--
ALTER TABLE `trends`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wholesaler_purchase_record_t`
--
ALTER TABLE `wholesaler_purchase_record_t`
  ADD PRIMARY KEY (`purchase_id`),
  ADD KEY `wholesaler_id` (`wholesaler_id`),
  ADD KEY `retailer_id` (`retailer_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `wholesaler_storage_inventory_t`
--
ALTER TABLE `wholesaler_storage_inventory_t`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wholesaler_t`
--
ALTER TABLE `wholesaler_t`
  ADD PRIMARY KEY (`wholesaler_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admininfo`
--
ALTER TABLE `admininfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admin_t`
--
ALTER TABLE `admin_t`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cart_items`
--
ALTER TABLE `cart_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `coldstorage`
--
ALTER TABLE `coldstorage`
  MODIFY `coldstorageid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `consumer_orders_t`
--
ALTER TABLE `consumer_orders_t`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `directory`
--
ALTER TABLE `directory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `farmer`
--
ALTER TABLE `farmer`
  MODIFY `farmer_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `historical_data`
--
ALTER TABLE `historical_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `item`
--
ALTER TABLE `item`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `livestock`
--
ALTER TABLE `livestock`
  MODIFY `livestock_batch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `meat_product_t`
--
ALTER TABLE `meat_product_t`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `orders_o_t`
--
ALTER TABLE `orders_o_t`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `production_record_t`
--
ALTER TABLE `production_record_t`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_reviews`
--
ALTER TABLE `product_reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_transactions`
--
ALTER TABLE `product_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `recommendation`
--
ALTER TABLE `recommendation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `recommendations`
--
ALTER TABLE `recommendations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `retailers`
--
ALTER TABLE `retailers`
  MODIFY `retailer_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `retailer_purchase_record_t`
--
ALTER TABLE `retailer_purchase_record_t`
  MODIFY `purchase_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `retailer_storage_inventory_t`
--
ALTER TABLE `retailer_storage_inventory_t`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `retailer_t`
--
ALTER TABLE `retailer_t`
  MODIFY `retailer_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `selling_buying_directory`
--
ALTER TABLE `selling_buying_directory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `singing`
--
ALTER TABLE `singing`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `trends`
--
ALTER TABLE `trends`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `wholesaler_purchase_record_t`
--
ALTER TABLE `wholesaler_purchase_record_t`
  MODIFY `purchase_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wholesaler_storage_inventory_t`
--
ALTER TABLE `wholesaler_storage_inventory_t`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `wholesaler_t`
--
ALTER TABLE `wholesaler_t`
  MODIFY `wholesaler_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `retailer_purchase_record_t`
--
ALTER TABLE `retailer_purchase_record_t`
  ADD CONSTRAINT `retailer_purchase_record_t_ibfk_1` FOREIGN KEY (`retailer_id`) REFERENCES `retailer_t` (`retailer_id`),
  ADD CONSTRAINT `retailer_purchase_record_t_ibfk_2` FOREIGN KEY (`wholesaler_id`) REFERENCES `wholesaler_t` (`wholesaler_id`),
  ADD CONSTRAINT `retailer_purchase_record_t_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
